# file <loss.py>

def loss(ans, y_ans, name):
    print(f'\'{y_ans}\' is wrong answer ;(. Correct answer was\'{ans}\'.')
    print(f'Let\'s try again, {name}')
