# file <brain_progression.py>


from brain_games.scripts.foo_all import progression


def main():
    progression()


if __name__ == '__main__':
    main()
