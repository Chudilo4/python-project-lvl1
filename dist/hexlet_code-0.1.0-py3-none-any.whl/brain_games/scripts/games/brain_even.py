# file <brain_even.py>


from brain_games.scripts.foo_all import parity


def main():
    parity()


if __name__ == '__main__':
    main()
