# file <foo_prime.py>


def foo_prime(n):
    for i in range(2, n):
        if n % i == 0:
            an_tr = "no"
            return an_tr
        else:
            an_tr
