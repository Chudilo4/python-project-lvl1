# file <foo_create_progression.py>

def foo_create_progression(start, diff):
    p = ()
    count = start
    for i in range(0, 10):
        p[i] = count + diff
        count += diff
    return p
