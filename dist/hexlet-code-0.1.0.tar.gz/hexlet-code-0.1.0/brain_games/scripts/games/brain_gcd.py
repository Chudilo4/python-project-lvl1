# file <brain_gcd.py>


from brain_games.scripts.foo_all import gcd


def main():
    gcd()


if __name__ == '__main__':
    main()
