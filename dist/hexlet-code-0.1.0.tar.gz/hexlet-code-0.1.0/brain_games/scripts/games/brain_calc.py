# file <brain_calc.py>


from brain_games.scripts.foo_all import question


def main():
    question()


if __name__ == '__main__':
    main()
