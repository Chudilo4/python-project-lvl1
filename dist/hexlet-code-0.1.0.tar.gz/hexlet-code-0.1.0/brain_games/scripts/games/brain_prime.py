# file <brain_prime.py>


from brain_games.scripts.foo_all import prime


def main():
    prime()


if __name__ == '__main__':
    main()
