#!/usr/bin/env python


from brain_games.scripts.foo_all import hello


def main():
    hello()


if __name__ == '__main__':
    main()
