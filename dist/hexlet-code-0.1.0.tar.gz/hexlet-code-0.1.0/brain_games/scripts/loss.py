# file <loss.py>

def loss(an_tr, an_us, name):
    print(f'\'{an_us}\' is wrong answer ;(. Correct answer was\'{an_tr}\'.')
    print(f'Let\'s try again, {name}!')
